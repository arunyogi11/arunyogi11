export  class Cust
{
    First_name:String;
    Last_name:String;
    Address:String;
    City:String;
    State:String;
    order_Total:number;

}