import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';
import { User } from '../_models/User';
import { Cust } from '../_models/cust';
import { UserService } from '../_services/user.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  loading = false;
  users: User[];

  constructor(private userService: UserService) { }

  ngOnInit(): void {
    this.loading = true;
        this.userService.getAll().pipe(first()).subscribe(users => {
            this.loading = false;
            this.users = users});
  }

  characters: Cust[] = [
    {
    First_name: 'Ram',
    Last_name: 'Kumar',
    Address: 'Delhi',
  City: 'Delhi',
  State: 'Delhi',
  order_Total:200
    },
    {
    First_name: 'Sham',
    Last_name: 'Kumar',
    Address: 'Panaji',
  City: 'Panaji',
  State: 'Goa',
  order_Total:250
    },
    {
      First_name: 'Ritu',
    Last_name: 'Rathi',
    Address: 'Pune',
  City: 'Pune',
  State: 'Maharashtra',
  order_Total:1200
    },
    {
  First_name: 'Gourav',
    Last_name: 'Kumar',
    Address: 'Mumbai',
  City: 'Mumbai',
  State: 'Maharashtra',
  order_Total:300
    }
  ];

}
