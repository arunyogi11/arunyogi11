import { Component, OnInit } from '@angular/core';
import { User } from './_models/User';




//import { UserService } from '../_services/user.service';
import { first } from 'rxjs/operators';

import { UserService } from './_services/user.service';
import { AuthenticationService } from './_services/authentication.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {// implements OnInit {
  title = 't-project';

/* loading: boolean;
  users: User[];
  constructor(private userService: UserService) { }


  ngOnInit(): void {
   /* this.loading = true;
        this.userService.getAll().pipe(first()).subscribe(users => {
            this.loading = false;
            this.users = users});*/

      

}
