import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms'; 
import { AppRoutingModule , RoutingComponent} from './app-routing.module'; 
import { AppComponent } from './app.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { CustomerComponent } from './customer/customer.component';
import { OrderComponent } from './order/order.component';
import { AboutComponent } from './about/about.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { JwtInterceptor  } from './_helpers/jwt.interceptor';
import { ErrorInterceptor  } from './_helpers/error.interceptor';
import { AuthGuard } from './_helpers/auth.guard';
import { FakeBackendInterceptor } from './_helpers/fake-backend';
import { fakeBackendProvider } from './_helpers/fake-backend';
import { AuthenticationService } from './_services/authentication.service';






@NgModule({
  declarations: [
    AppComponent,
       RoutingComponent,
       LoginPageComponent,
       CustomerComponent,
       OrderComponent,
       AboutComponent,
       SignupComponent,
       LoginComponent
    
       
   
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
    /*AuthGuard,
    JwtInterceptor,
    ErrorInterceptor,
    FakeBackendInterceptor*/
    
  
    
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },

        // provider used to create fake backend
        fakeBackendProvider,
        AuthenticationService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
