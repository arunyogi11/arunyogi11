import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginPageComponent } from './login-page/login-page.component';
import {CustomerComponent} from './customer/customer.component';
import {OrderComponent} from './order/order.component';
import {AboutComponent} from './about/about.component';
import {LoginComponent} from './login/login.component';
import {SignupComponent} from './signup/signup.component';
import { AuthGuard  } from './_helpers/auth.guard';
import { JwtInterceptor  } from './_helpers/jwt.interceptor';
import { ErrorInterceptor  } from './_helpers/error.interceptor';

const routes: Routes = [
  {path:"login_logout", component:LoginPageComponent},
  {path:"view-customer", component:CustomerComponent},
  {path:"add-order",component:OrderComponent},
  {path:"add-about",component:AboutComponent},
  {path:"signup",component:SignupComponent},
  {path:"login",component:LoginComponent},
 
  { path: '', component: CustomerComponent, canActivate: [AuthGuard] },
  { path: 'login', component: LoginComponent },

  { path: '**', redirectTo: '' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule  { } export const 
RoutingComponent = [LoginPageComponent,CustomerComponent,OrderComponent,AboutComponent,SignupComponent,LoginComponent];
 